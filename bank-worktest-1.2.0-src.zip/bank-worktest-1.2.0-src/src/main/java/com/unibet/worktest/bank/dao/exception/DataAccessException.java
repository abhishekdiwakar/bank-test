package com.unibet.worktest.bank.dao.exception;

/**
 * This class represents the exception thrown by the DAO layer when there is
 * problem accessing data.
 * 
 * @author kanika
 * 
 */
public class DataAccessException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * No-arg Constructor.
	 */
	public DataAccessException() {
		super();
	}

	/**
	 * Constructor which takes Throwable class instance.
	 * 
	 * @param originalException
	 *            the throwable original exception
	 */
	public DataAccessException(final Throwable originalException) {
		super(originalException);
	}

	/**
	 * Constructor which takes message and Throwable class instance
	 * 
	 * @param message
	 *            The {@link Message} object which represents a message to log
	 * @param originalException
	 *            the throwable original exception
	 */
	public DataAccessException(final String message, final Throwable originalException) {
		super(message, originalException);
	}

}
