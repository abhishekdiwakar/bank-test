package com.unibet.worktest.bank.service;

import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.Currency;

import org.junit.Before;
import org.junit.Test;

import com.unibet.worktest.bank.InsufficientFundsException;
import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bank.TransferRequest;
import com.unibet.worktest.bank.UnbalancedLegsException;
import com.unibet.worktest.bank.dao.AccountDao;
import com.unibet.worktest.bank.dao.TransactionDao;
import com.unibet.worktest.bank.domain.Account;
import com.unibet.worktest.bank.domain.MonetaryTransaction;
import com.unibet.worktest.bank.service.impl.TransferServiceImpl;
import com.unibet.worktest.bank.service.mapper.TransactionMapper;

public class TransferServiceTest {

	private static final String TRANSACTION_REF = "T1";
	private static final String REVENUE_ACCOUNT_2 = "REVENUE_ACCOUNT_2";
	private static final String CASH_ACCOUNT_2 = "CASH_ACCOUNT_2";
	private static final String REVENUE_ACCOUNT_1 = "REVENUE_ACCOUNT_1";
	private static final String CASH_ACC = "CASH_ACCOUNT_1";
	private AccountDao accountDao;
	private TransactionDao transactionDao;
	private TransactionMapper mapper;
	private TransferService service;
	private TransferRequest transferRequest;

	@Before
	public void setup() {
		accountDao = mock(AccountDao.class);
		transactionDao = mock(TransactionDao.class);
		mapper = mock(TransactionMapper.class);
		service = new TransferServiceImpl(transactionDao, accountDao, mapper);
		transferRequest = TransferRequest.builder()
				.reference(TRANSACTION_REF)
				.type("testing")
				.account(CASH_ACC)
				.amount(toMoney("-5.00", "EUR"))
				.account(REVENUE_ACCOUNT_1)
				.amount(toMoney("5.00", "EUR"))
				.account(CASH_ACCOUNT_2)
				.amount(toMoney("-10.50", "SEK"))
				.account(REVENUE_ACCOUNT_2)
				.amount(toMoney("10.50", "SEK"))
				.build();

		Account cashAcc = new Account(CASH_ACC, toMoney("1000.00", "EUR"));
		Account revenueAcc = new Account(REVENUE_ACCOUNT_1, toMoney("100.00", "EUR"));
		Account cashAcc2 = new Account(CASH_ACCOUNT_2, toMoney("200.00", "SEK"));
		Account revenueAcc2 = new Account(REVENUE_ACCOUNT_2, toMoney("300.00", "SEK"));

		cashAcc.convertMoney();
		revenueAcc.convertMoney();
		cashAcc2.convertMoney();
		revenueAcc2.convertMoney();

		given(accountDao.getAccount(CASH_ACC, "EUR")).willReturn(cashAcc);
		given(accountDao.getAccount(REVENUE_ACCOUNT_1, "EUR")).willReturn(revenueAcc);
		given(accountDao.getAccount(CASH_ACCOUNT_2, "SEK")).willReturn(cashAcc2);
		given(accountDao.getAccount(REVENUE_ACCOUNT_2, "SEK")).willReturn(revenueAcc2);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldRejectTransferRequestWhenReferenceIsNull() throws Exception {
		// given
		transferRequest = TransferRequest.builder()
				.reference(null)
				.type("testing")
				.account(CASH_ACC)
				.amount(toMoney("-5.00", "EUR"))
				.account(REVENUE_ACCOUNT_1)
				.amount(toMoney("5.00", "EUR"))
				.account(CASH_ACCOUNT_2)
				.amount(toMoney("-10.50", "SEK"))
				.account(REVENUE_ACCOUNT_2)
				.amount(toMoney("10.50", "SEK"))
				.build();

		// when
		service.transferFunds(transferRequest);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldRejectransferRequestWhenTypeIsNull() throws Exception {
		// given
		transferRequest = TransferRequest.builder()
				.reference("testing")
				.type(null)
				.account(CASH_ACC)
				.amount(toMoney("-5.00", "EUR"))
				.account(REVENUE_ACCOUNT_1)
				.amount(toMoney("5.00", "EUR"))
				.account(CASH_ACCOUNT_2)
				.amount(toMoney("-10.50", "SEK"))
				.account(REVENUE_ACCOUNT_2)
				.amount(toMoney("10.50", "SEK"))
				.build();

		// when
		service.transferFunds(transferRequest);
	}

	@Test(expected = UnbalancedLegsException.class)
	public void shouldRejectIfUnbalancedLegs() throws Exception {
		// given
		transferRequest = TransferRequest.builder()
				.reference(TRANSACTION_REF)
				.type("testing")
				.account(CASH_ACC)
				.amount(toMoney("-5.00", "EUR"))
				.account(REVENUE_ACCOUNT_1)
				.amount(toMoney("5.00", "EUR"))
				.account(CASH_ACCOUNT_2)
				.amount(toMoney("-10.50", "SEK"))
				.account(REVENUE_ACCOUNT_2)
				.amount(toMoney("2.50", "SEK"))
				.build();

		// when
		service.transferFunds(transferRequest);
	}

	@Test(expected = InsufficientFundsException.class)
	public void shouldNotAllowAccountToBeOverdrawn() throws Exception {
		// given
		Account account = new Account(CASH_ACC, toMoney("4.00", "EUR"));
		account.convertMoney();
		given(accountDao.getAccount(CASH_ACC, "EUR")).willReturn(account);

		// when
		service.transferFunds(transferRequest);
	}

	@Test
	public void shouldSaveTransactionIfFundsTransferred() throws Exception {
		// given
		// when
		service.transferFunds(transferRequest);

		// then
		verify(transactionDao, times(1)).saveTransaction(any(MonetaryTransaction.class));
	}

	@Test
	public void shouldGetTransactionByRef() throws Exception {
		// given
		// when
		service.getTransactionByRef(TRANSACTION_REF);

		// then
		verify(transactionDao, times(1)).findTransactionByRef(TRANSACTION_REF);
	}

	@Test
	public void shouldGetTransactionByAccounRef() throws Exception {
		// given
		// when
		service.findTransactionsByAccountRef(CASH_ACC);

		// then
		verify(transactionDao, times(1)).findTransactionsByAccountRef(CASH_ACC);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowExceptionIfTransactionRefIsNull() throws Exception {
		// when
		service.getTransactionByRef(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowExceptionIfAccountRefIsNull() throws Exception {
		// when
		service.findTransactionsByAccountRef(null);
	}

	private static Money toMoney(String amount, String currency) {
		return new Money(new BigDecimal(amount), Currency.getInstance(currency));
	}
}
