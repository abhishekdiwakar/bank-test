/**
 * 
 */
/**
 * @author kanika
 *
 */
package com.unibet.worktest.bank.dao.exception;