package com.unibet.worktest.bank;

import static org.fest.assertions.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.Currency;

import org.junit.Before;
import org.junit.Test;

public class TransferRequestDTOTest {

	private TransferRequestDTO transferRequest;

	// @formatter:off
	@Before
	public void setUp() {
		transferRequest = new TransferRequestDTO(TransferRequest.builder()
				.reference("T1")
				.type("testing")
				.account("CASH_ACCOUNT_1")
				.amount(toMoney("-5.00", "EUR"))
				.account("REVENUE_ACCOUNT_1")
				.amount(toMoney("5.00", "EUR"))
				.account("CASH_ACCOUNT_2")
				.amount(toMoney("-10.50", "SEK"))
				.account("REVENUE_ACCOUNT_2")
				.amount(toMoney("10.50", "SEK"))
				.build());
	}


	@Test
	public void shouldReturnFalseIfGreaterThanTwoLegs() {
		// when
		// then
		assertThat(transferRequest.hasLessThanTwoLegs()).isFalse();
	}

	@Test(expected = IllegalStateException.class)
	public void shouldThrowExceptionIfLessThanTwoLegs() {
		// when
		// then
		transferRequest = new TransferRequestDTO(TransferRequest.builder()
					.reference("T1")
					.type("testing")
					.account("CASH_ACCOUNT_1")
					.amount(toMoney("-5.00", "EUR"))
					.build());
	}
	
	@Test
	public void shouldCheckIfLegsWithSameCurrencyAreBalanced() {
		// when
		// then
		assertThat(transferRequest.legsWithSameCurrencyAreUnbalanced()).isFalse();
	}
	
	@Test
	public void shouldCheckIfLegsWithSameCurrencyAreUnbalanced() {
		// when
		// then
		transferRequest = new TransferRequestDTO(TransferRequest.builder()
					.reference("T1")
					.type("testing")
					.account("CASH_ACCOUNT_1")
					.amount(toMoney("-5.00", "EUR"))
					.account("REVENUE_ACCOUNT_1")
					.amount(toMoney("5.00", "EUR"))
					.account("CASH_ACCOUNT_2")
					.amount(toMoney("-10.50", "SEK"))
					.account("REVENUE_ACCOUNT_2")
					.amount(toMoney("2.50", "SEK"))
					.build());
		
		assertThat(transferRequest.legsWithSameCurrencyAreUnbalanced()).isTrue();
	}
	

	private static Money toMoney(String amount, String currency) {
		return new Money(new BigDecimal(amount), Currency.getInstance(currency));
	}
	// @formatter:on

}
