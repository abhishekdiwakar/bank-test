package com.unibet.worktest.bank.dao;

import java.util.List;

import com.unibet.worktest.bank.InfrastructureException;
import com.unibet.worktest.bank.TransactionNotFoundException;
import com.unibet.worktest.bank.domain.MonetaryTransaction;

// TODO: Auto-generated Javadoc
/**
 * Interface representing a domain repository of transaction.
 */
public interface TransactionDao extends BaseDao<MonetaryTransaction, String> {

	/**
	 * Saves the transaction.
	 *
	 * @param transaction
	 *            the transaction
	 * @throws InfrastructureException
	 *             on unrecoverable infrastructure errors
	 */
	void saveTransaction(MonetaryTransaction transaction) throws InfrastructureException;

	/**
	 * Finds the transactions by account reference.
	 *
	 * @param accountRef
	 *            the account reference
	 * @return List of Transactions
	 * @throws InfrastructureException
	 *             on unrecoverable infrastructure errors
	 */
	List<MonetaryTransaction> findTransactionsByAccountRef(String accountRef) throws InfrastructureException;

	/**
	 * Finds transaction by transaction reference.
	 *
	 * @param transactionRef
	 *            the transaction reference
	 * @return Transaction
	 * @throws TransactionNotFoundException
	 *             the transaction not found exception
	 */
	MonetaryTransaction findTransactionByRef(String transactionRef) throws TransactionNotFoundException;

}
