package com.unibet.worktest.bank.dao;

import com.unibet.worktest.bank.AccountDetailsMissingException;
import com.unibet.worktest.bank.AccountNotFoundException;
import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bank.domain.Account;

public interface AccountDao extends BaseDao<Account, String> {
	/**
	 * Create a new account with an initial balance.
	 *
	 * @param accountRef
	 *            the reference of account that needs to be created
	 * @param balance
	 *            the account balance
	 * @throws AccountDetailsMissingException
	 *             issues while creating account
	 */
	public void createAccount(String accountRef, Money balance) throws AccountDetailsMissingException;

	/**
	 * Returns the account for account reference.
	 * 
	 * @param accountRef
	 *            account reference
	 * @return Account account with account reference
	 * @throws AccountNotFoundException
	 *             if no account found
	 */
	Account getAccount(String accountRef) throws AccountNotFoundException;

	/**
	 * Returns the account for given account reference and currency code.
	 * 
	 * @param accountRef
	 *            account reference
	 * @param currencyCode
	 *            currency code
	 * @return Account account with given account reference and currency
	 * @throws AccountNotFoundException
	 *             if the referenced account is not found
	 */
	Account getAccount(String accountRef, String currencyCode) throws AccountNotFoundException;

	/**
	 * This function is used to update the account balance
	 *
	 * @param account
	 *            - the account object that needs to be updated
	 * @throws AccountDetailsMissingException
	 *             issues while updating account
	 *
	 */
	void updateAccount(Account account) throws AccountDetailsMissingException;

}
