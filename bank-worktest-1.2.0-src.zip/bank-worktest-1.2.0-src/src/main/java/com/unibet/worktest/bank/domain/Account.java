package com.unibet.worktest.bank.domain;

import java.math.BigDecimal;
import java.util.Currency;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.unibet.worktest.bank.Money;

/**
 * Hibernate account entity
 * 
 *
 */
@Entity
@Table(name = "tAccount")
public class Account {
	@Id
	private String accountRef;

	@Column(nullable = false)
	private BigDecimal amount;

	@Column(length = 3, nullable = false)
	private String currency;

	@Transient
	private Money balance;

	@PreUpdate
	@PrePersist
	public void convertMoney() {
		this.amount = balance.getAmount();
		this.currency = balance.getCurrency().getCurrencyCode();
	}

	@PostLoad
	public void convertToMoney() {
		balance = new Money(amount, Currency.getInstance(currency));
	}

	public Account() {
	}

	public Account(String accountRef, Money balance) {
		this.accountRef = accountRef;
		this.balance = balance;
	}

	public String getAccountRef() {
		return accountRef;
	}

	public Money getBalance() {
		return balance;
	}

	public void addAmount(BigDecimal amount) {
		this.amount = this.amount.add(amount);
		this.balance = new Money(this.amount, Currency.getInstance(currency));
	}

	public boolean isOverdrawn() {
		return amount.signum() == -1;
	}

}