package com.unibet.worktest.bank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class TransferRequestDTO {

	private String transactionRef;

	private String transactionType;

	private List<TransactionLeg> legs = new ArrayList<>();

	public TransferRequestDTO(TransferRequest request) {
		this.transactionRef = request.getTransactionRef();
		this.transactionType = request.getTransactionType();
		this.legs = request.getLegs();
	}

	public List<TransactionLeg> getLegs() {
		return Collections.unmodifiableList(legs);
	}

	public String getTransactionRef() {
		return transactionRef;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public boolean hasLessThanTwoLegs() {
		return null == legs || legs.size() < 2;
	}

	// @formatter:off
	public boolean legsWithSameCurrencyAreUnbalanced() {
		return (legs.stream()
				.collect(Collectors.groupingByConcurrent(TransactionLeg::getCurrencyCode, Collectors.summingDouble(TransactionLeg::getAmountValue)))
				.values().stream()
				.filter(amountValue -> amountValue != 0)
				.findFirst()
				.isPresent());
	}
}
