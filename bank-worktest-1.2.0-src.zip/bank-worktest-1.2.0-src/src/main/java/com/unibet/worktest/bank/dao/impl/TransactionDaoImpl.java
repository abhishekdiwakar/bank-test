package com.unibet.worktest.bank.dao.impl;

import java.util.List;

import javax.persistence.LockTimeoutException;
import javax.persistence.PessimisticLockException;
import javax.persistence.QueryTimeoutException;
import javax.persistence.TransactionRequiredException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.unibet.worktest.bank.InfrastructureException;
import com.unibet.worktest.bank.TransactionNotFoundException;
import com.unibet.worktest.bank.dao.TransactionDao;
import com.unibet.worktest.bank.dao.exception.DataAccessException;
import com.unibet.worktest.bank.dao.exception.DataNotFoundException;
import com.unibet.worktest.bank.domain.MonetaryTransaction;

@Repository
public class TransactionDaoImpl extends BaseDaoImpl<MonetaryTransaction, String> implements TransactionDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionDaoImpl.class);

	@Override
	public void saveTransaction(MonetaryTransaction transaction) {
		try {
			persist(transaction);
		} catch (DataAccessException e) {
			LOGGER.error("Error occured : {}", e);
			throw new InfrastructureException(e);
		}
	}

	@Override
	public List<MonetaryTransaction> findTransactionsByAccountRef(String accountRef) {
		try {
			return createNamedQuery("transaction.findTransactionsByAccountRef")
					.setParameter("accountRef", accountRef).getResultList();
		} catch (QueryTimeoutException | TransactionRequiredException | PessimisticLockException | LockTimeoutException e) {
			LOGGER.error("Error occured : {}", e);
			throw new InfrastructureException(e);
		}

	}

	@Override
	public MonetaryTransaction findTransactionByRef(String transactionRef) {
		try {
			return find(transactionRef);
		} catch (DataNotFoundException e) {
			LOGGER.error("Error occured : {}", e);
			throw new TransactionNotFoundException("No transaction found with reference " + transactionRef);
		}
	}

}
