package com.unibet.worktest.bank.service.mapper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unibet.worktest.bank.Transaction;
import com.unibet.worktest.bank.TransactionLeg;
import com.unibet.worktest.bank.domain.MonetaryTransaction;

/**
 * Service to map TransactionDetails into Transaction
 *
 */
@Service
public class TransactionMapper extends BaseMapper<MonetaryTransaction, Transaction> {

	private TransactionLegMapper mapper;

	@Autowired
	public TransactionMapper(TransactionLegMapper mapper) {
		this.mapper = mapper;
	}

	@Override
	public Transaction map(MonetaryTransaction monetaryTransaction) {
		List<TransactionLeg> legs = mapper.map(monetaryTransaction.getLegs());
		return new Transaction(monetaryTransaction.getTransactionRef(), monetaryTransaction.getTransactionType(), monetaryTransaction.getTransactionDate(), legs);
	}

}
