package com.unibet.worktest.bank.dao.exception;

/**
 * This class represents the exception thrown by the DAO layer when no data is
 * found.
 * 
 * @author kanika
 * 
 */
public class DataNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * No-arg Constructor.
	 */
	public DataNotFoundException() {
		super();
	}

	/**
	 * Constructor which takes Throwable class instance.
	 * 
	 * @param originalException
	 *            the throwable original exception
	 */
	public DataNotFoundException(final Throwable originalException) {
		super(originalException);
	}

	/**
	 * Constructor which takes message.
	 * 
	 * @param message
	 *            message to log
	 * 
	 */
	public DataNotFoundException(final String message) {
		super(message);
	}

	/**
	 * Constructor which takes message and Throwable class instance
	 * 
	 * @param message
	 *            message to log
	 * @param originalException
	 *            the throwable original exception
	 */
	public DataNotFoundException(final String message, final Throwable originalException) {
		super(message, originalException);
	}
}
