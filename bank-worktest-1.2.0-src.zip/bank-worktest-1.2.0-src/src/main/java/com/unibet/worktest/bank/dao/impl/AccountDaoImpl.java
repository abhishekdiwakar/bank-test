package com.unibet.worktest.bank.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.unibet.worktest.bank.AccountDetailsMissingException;
import com.unibet.worktest.bank.AccountNotFoundException;
import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bank.dao.AccountDao;
import com.unibet.worktest.bank.dao.exception.DataAccessException;
import com.unibet.worktest.bank.dao.exception.DataNotFoundException;
import com.unibet.worktest.bank.domain.Account;

@Repository
public class AccountDaoImpl extends BaseDaoImpl<Account, String> implements AccountDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountDaoImpl.class);

	@Override
	public void createAccount(String accountRef, Money balance) {
		try {
			persist(new Account(accountRef, balance));
		} catch (DataAccessException e) {
			LOGGER.error("Error occured while creating account. {}", e);
			throw new AccountDetailsMissingException("Error occured while creating account.");
		}
	}

	@Override
	public Account getAccount(String accountRef) {
		try {
			return find(accountRef);
		} catch (DataNotFoundException e) {
			e.printStackTrace();
			throw new AccountNotFoundException(accountRef);
		}
	}

	@Override
	public Account getAccount(String accountRef, String currencyCode) {
		try {
			TypedQuery<Account> query = getQuery("SELECT acc FROM Account acc WHERE acc.accountRef=:accountRef AND acc.currency=:currencyCode");
			query.setParameter("accountRef", accountRef);
			query.setParameter("currencyCode", currencyCode);
			return query.getSingleResult();
		} catch (NoResultException e) {
			LOGGER.error("No account found for reference {} and currency {}. {}", accountRef, currencyCode, e);
			throw new AccountNotFoundException(accountRef);
		}
	}

	@Override
	public void updateAccount(Account account) {
		try {
			update(account);
		} catch (DataAccessException e) {
			LOGGER.error("Error occured while updating account. {}", e);
			throw new AccountDetailsMissingException("Error occured while updating account.");
		}
	}
}
