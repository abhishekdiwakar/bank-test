package com.unibet.worktest.bank.domain;

import java.math.BigDecimal;
import java.util.Currency;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Transient;

import org.hibernate.annotations.Immutable;

import com.unibet.worktest.bank.Money;

/**
 * Immutable Hibernate entity to persist the AccountTransactionLegs
 *
 * @see MonetaryTransaction
 *
 */
@Entity
@Immutable
public class MonetaryTransactionLeg {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long legId;

	@ManyToOne(cascade = { CascadeType.DETACH }, fetch = FetchType.LAZY)
	@JoinColumn(name = "accountRef", referencedColumnName = "accountRef")
	private Account account;

	@Column(name = "amount", nullable = false)
	private BigDecimal amountValue;

	@Column(length = 3, nullable = false)
	private String currency;

	@Transient
	private Money amount;

	@PreUpdate
	@PrePersist
	public void convertMoney() {
		this.amountValue = amount.getAmount();
		this.currency = amount.getCurrency().getCurrencyCode();
	}

	@PostLoad
	public void convertToMoney() {
		amount = new Money(amountValue, Currency.getInstance(currency));
	}

	public MonetaryTransactionLeg() {
	}

	public MonetaryTransactionLeg(Account account, Money amount) {
		this.account = account;
		this.amount = amount;
	}

	public Account getAccount() {
		return account;
	}

	public Money getAmount() {
		return amount;
	}

}
