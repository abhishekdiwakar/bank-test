/**
 * 
 */
/**
 * @author kanika
 *
 */
package com.unibet.worktest.bank.domain;