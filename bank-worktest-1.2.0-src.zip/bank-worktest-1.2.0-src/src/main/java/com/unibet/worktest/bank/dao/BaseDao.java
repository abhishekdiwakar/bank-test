package com.unibet.worktest.bank.dao;

import java.io.Serializable;

import com.unibet.worktest.bank.dao.exception.DataAccessException;
import com.unibet.worktest.bank.dao.exception.DataNotFoundException;
import com.unibet.worktest.bank.dao.impl.BaseDaoImpl;

/**
 * The <code>BaseDao</code> provides an abstraction for common database CRUD
 * operations for a persistence entity. This is a generic interface which must
 * be extended by all DAO interfaces for specific entities. Concrete DAO
 * implementations should extend {@link BaseDaoImpl} rather than implementing
 * this interface directly.
 * 
 * @author kanika
 * 
 * @param <T>
 *            Persistence entity type
 * @param <ID>
 *            Data type of persistence entity's primary key
 */
public interface BaseDao<T, ID extends Serializable> {
	/**
	 * Persists the provided entity in database.
	 * 
	 * @param entity
	 *            entity instance
	 * @throws DataAccessException
	 *             if any error occurs while persisting provided entity
	 */
	void persist(final T entity) throws DataAccessException;

	/**
	 * Updates the provided entity in database.
	 *
	 * @param entity
	 *            entity instance
	 * @throws DataAccessException
	 *             if any error occurs while updating provided entity
	 */
	void update(final T entity) throws DataAccessException;

	/**
	 * Deletes the provided entity instance from database.
	 * 
	 * @param entity
	 *            entity instance
	 * @throws DataAccessException
	 *             if any error occurs while deleting provided entity
	 */
	void delete(final T entity) throws DataAccessException;

	/**
	 * Fetches an entity by primary key from database.
	 * 
	 * @param reference
	 *            Primary key of entity
	 * @return the found entity instance
	 * @throws DataAccessException
	 *             if any error occurs while fetching entity for provided
	 *             primary key
	 * @throws DataNotFoundException
	 *             in case if the entity does not exist
	 */
	T find(final String reference) throws DataAccessException, DataNotFoundException;
}
