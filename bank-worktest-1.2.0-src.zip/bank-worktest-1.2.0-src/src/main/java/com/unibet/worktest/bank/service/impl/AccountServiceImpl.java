package com.unibet.worktest.bank.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.unibet.worktest.bank.AccountNotFoundException;
import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bank.dao.AccountDao;
import com.unibet.worktest.bank.service.AccountService;

@Service("accountService")
public class AccountServiceImpl implements AccountService {
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountServiceImpl.class);

	private AccountDao accountDao;

	@Autowired
	public AccountServiceImpl(AccountDao accountDao) {
		this.accountDao = accountDao;
	}

	@Override
	@Transactional(readOnly = false)
	public void createAccount(String accountRef, Money balance) {
		if (StringUtils.isEmpty(accountRef) || null == balance) {
			LOGGER.error("Account Ref or Balance cannot be null");
			throw new IllegalArgumentException("Account Ref or Balance cannot be null");
		}

		accountDao.createAccount(accountRef, balance);
	}

	@Override
	public Money getAccountBalance(String accountRef) throws AccountNotFoundException {
		if (StringUtils.isEmpty(accountRef)) {
			LOGGER.error("Account Ref cannot be null");
			throw new IllegalArgumentException("Account Ref cannot be null");
		}

		return accountDao.getAccount(accountRef).getBalance();
	}
}
