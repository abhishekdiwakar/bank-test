package com.unibet.worktest.bank.service.mapper;

import org.springframework.stereotype.Service;

import com.unibet.worktest.bank.TransactionLeg;
import com.unibet.worktest.bank.domain.MonetaryTransactionLeg;

/**
 * Service to map AccountTransactionLeg into TransactionLeg
 *
 */
@Service
public class TransactionLegMapper extends BaseMapper<MonetaryTransactionLeg, TransactionLeg> {

	@Override
	public TransactionLeg map(MonetaryTransactionLeg leg) {
		return new TransactionLeg(leg.getAccount().getAccountRef(), leg.getAmount());
	}

}
