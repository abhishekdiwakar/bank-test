package com.unibet.worktest.bank.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.Currency;

import org.junit.Before;
import org.junit.Test;

import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bank.dao.AccountDao;
import com.unibet.worktest.bank.dao.exception.DataAccessException;
import com.unibet.worktest.bank.service.impl.AccountServiceImpl;

public class AccountServiceTest {

	private static final String CASH_ACCOUNT_1 = "cash_1_EUR";
	private AccountDao accountDao;
	private AccountService accountService;
	private Money balance;

	@Before
	public void setup() {
		accountDao = mock(AccountDao.class);
		accountService = new AccountServiceImpl(accountDao);
		balance = new Money(BigDecimal.valueOf(1000), Currency.getInstance("EUR"));
	}

	@Test
	public void shouldCreateAccountWithAccountRefAndBalance() throws DataAccessException {
		// when
		accountService.createAccount(CASH_ACCOUNT_1, balance);

		// then
		verify(accountDao, times(1)).createAccount(CASH_ACCOUNT_1, balance);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowExceptionIfAccountRefIsNull() {
		// when
		accountService.createAccount(null, balance);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowExceptionIfBalanceIsNull() {
		// when
		accountService.createAccount(CASH_ACCOUNT_1, null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowExceptionIfAccountRefIsNullWhenGettingAccount() {
		// when
		accountService.getAccountBalance(null);
	}

	public void shouldGetAccount() {
		// when
		accountService.getAccountBalance(CASH_ACCOUNT_1);

		// then
		verify(accountDao, times(1)).getAccount(CASH_ACCOUNT_1);
	}

}
