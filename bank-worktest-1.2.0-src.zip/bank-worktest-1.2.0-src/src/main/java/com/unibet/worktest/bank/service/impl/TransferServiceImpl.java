package com.unibet.worktest.bank.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.unibet.worktest.bank.InsufficientFundsException;
import com.unibet.worktest.bank.Transaction;
import com.unibet.worktest.bank.TransferRequest;
import com.unibet.worktest.bank.TransferRequestDTO;
import com.unibet.worktest.bank.UnbalancedLegsException;
import com.unibet.worktest.bank.dao.AccountDao;
import com.unibet.worktest.bank.dao.TransactionDao;
import com.unibet.worktest.bank.domain.Account;
import com.unibet.worktest.bank.domain.MonetaryTransaction;
import com.unibet.worktest.bank.domain.MonetaryTransactionLeg;
import com.unibet.worktest.bank.service.TransferService;
import com.unibet.worktest.bank.service.mapper.TransactionMapper;

@Service("transferService")
public class TransferServiceImpl implements TransferService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TransferServiceImpl.class);

	private final AccountDao accountDao;
	private final TransactionDao transactionDao;
	private final TransactionMapper mapper;

	@Autowired
	public TransferServiceImpl(TransactionDao transactionDao, AccountDao accountDao, TransactionMapper mapper) {
		this.transactionDao = transactionDao;
		this.accountDao = accountDao;
		this.mapper = mapper;
	}

	@Override
	@Transactional(readOnly = false, isolation = Isolation.REPEATABLE_READ)
	public void transferFunds(final TransferRequest request) {
		TransferRequestDTO transferRequest = new TransferRequestDTO(request);
		validateTransferRequest(transferRequest);

		if (transferRequest.legsWithSameCurrencyAreUnbalanced()) {
			throw new UnbalancedLegsException("Transaction Legs for same currency are unbalanced.");
		}

		List<MonetaryTransactionLeg> legs = new ArrayList<>();
		transferRequest.getLegs().stream()
				.forEach(transactionLeg -> {
					Account account = accountDao.getAccount(transactionLeg.getAccountRef(), transactionLeg.getCurrencyCode());
					account.addAmount(transactionLeg.getAmount().getAmount());
					if (account.isOverdrawn()) {
						throw new InsufficientFundsException("Insufficient balance in account with reference " + transactionLeg.getAccountRef()
								+ " for performing transfer of amount " + transactionLeg.getAmount().getAmount());
					}
					accountDao.updateAccount(account);
					legs.add(new MonetaryTransactionLeg(account, transactionLeg.getAmount()));
				});

		transactionDao.saveTransaction(new MonetaryTransaction(transferRequest.getTransactionRef(), transferRequest.getTransactionType(), legs));
		LOGGER.info("Transfer Request complete");
	}

	@Override
	public List<Transaction> findTransactionsByAccountRef(final String accountRef) {
		if (StringUtils.isEmpty(accountRef)) {
			LOGGER.error("Account reference cannot be null or empty");
			throw new IllegalArgumentException("Account reference cannot be null or empty");
		}
		return mapper.map(transactionDao.findTransactionsByAccountRef(accountRef));
	}

	@Override
	public Transaction getTransactionByRef(final String transactionRef) {
		if (StringUtils.isEmpty(transactionRef)) {
			LOGGER.error("Transaction reference cannot be null or empty");
			throw new IllegalArgumentException("Transaction reference cannot be null or empty");
		}
		return mapper.map(transactionDao.findTransactionByRef(transactionRef));
	}

	private void validateTransferRequest(TransferRequestDTO transferRequest) {
		if (transferRequest.hasLessThanTwoLegs()) {
			throw new IllegalArgumentException("Transaction legs cannot be less than two, at least one debit and one credit entry is required");
		} else if (StringUtils.isEmpty(transferRequest.getTransactionRef())) {
			throw new IllegalArgumentException("Transaction reference cannot be null or empty");
		} else if (StringUtils.isEmpty(transferRequest.getTransactionType())) {
			throw new IllegalArgumentException("Transaction type cannot be null or empty");
		}
	}

}
