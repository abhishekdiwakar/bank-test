package com.unibet.worktest.bank.service.mapper;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Abstract class which acts as super class for any mapper class providing a
 * generic functionality to map to/from list provided implementation to map
 * to/from objects is implemented.
 *
 * @param <F>
 * @param <T>
 */
public abstract class BaseMapper<F, T> {
	public abstract T map(F from);

	public List<T> map(List<F> fromList) {
		if (fromList == null) {
			throw new RuntimeException();
		}
		List<T> result = new ArrayList<T>();
		for (F from : fromList) {
			result.add(map(from));
		}
		return result;
	}

}
