package com.unibet.worktest.bank.dao.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;
import javax.persistence.TypedQuery;

import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.unibet.worktest.bank.dao.BaseDao;
import com.unibet.worktest.bank.dao.exception.DataAccessException;
import com.unibet.worktest.bank.dao.exception.DataNotFoundException;

/**
 * The <code>BaseDaoImpl</code> provides implementation of {@link BaseDao} for
 * common database CRUD operations for a persistence entity. All DAO
 * implementations for specific entities must extend this class.
 * 
 * @author kanika
 * 
 * @param <T>
 *            Persistence entity type
 * @param <ID>
 *            Data type of persistence entity's primary key
 */
@Repository
public abstract class BaseDaoImpl<T, ID extends Serializable> implements BaseDao<T, ID> {
	private static final Logger LOGGER = LoggerFactory.getLogger(BaseDaoImpl.class);

	/** Constant for various numeric validations */
	private static final int ZERO = 0;

	/** Instance used to interact with persistence context. */
	@PersistenceContext
	private EntityManager entityManager;

	/** Class of Persistence entity */
	private Class<T> entityClass;

	private T T;

	@Override
	public void persist(final T entity) throws DataAccessException {
		try {
			entityManager.persist(entity);
			entityManager.flush();
		} catch (TransactionRequiredException e) {
			LOGGER.error(e.getMessage());
			throw new DataAccessException(e);
		} catch (EntityExistsException e) {
			LOGGER.error(e.getMessage());
			throw new DataAccessException("The entity to persist already exist", e);
		} catch (PersistenceException e) {
			if (e.getCause() instanceof ConstraintViolationException) {
				LOGGER.error(e.getMessage());
				throw new DataAccessException(e);
			}
		}
	}

	@Override
	public void update(final T entity) throws DataAccessException {
		try {
			entityManager.merge(entity);
		} catch (TransactionRequiredException e) {
			LOGGER.error(e.getMessage());
			throw new DataAccessException(e);
		}
	}

	@Override
	public void delete(final T entity) throws DataAccessException {
		try {
			entityManager.remove(entity);
		} catch (TransactionRequiredException e) {
			LOGGER.error(e.getMessage());
			throw new DataAccessException(e);
		}
	}

	@Override
	public T find(final String reference) throws DataNotFoundException {
		T entity = entityManager.find(getEntityClass(), reference);
		if (entity == null) {
			throw new DataNotFoundException(getEntityClass() + " not found for reference " + reference);
		}
		return entity;
	}

	/**
	 * Create an instance of <code>Query</code> for executing a named query
	 * 
	 * @param name
	 *            the name of a query defined in metadata
	 * @return the new query instance
	 * 
	 */
	protected Query createNamedQuery(String name) {
		return entityManager.createNamedQuery(name, getEntityClass());
	}

	/**
	 * Gets the native query.
	 * 
	 * @param query
	 *            the query
	 * @return the typed query
	 */
	protected TypedQuery<T> getQuery(final String query) {
		return entityManager.createQuery(query, getEntityClass());
	}

	/**
	 * Returns the persistence entity's class.
	 * 
	 * @return Persistence entity's class
	 */
	private Class<T> getEntityClass() {
		if (this.entityClass == null) {
			final Class<?> targetClass = this.getClass();
			this.entityClass = this.getParameterizedClass(targetClass);
		}
		return this.entityClass;
	}

	/**
	 * Identifies and returns the parameterized class from provided class.
	 * 
	 * @param targetClass
	 *            Target class from which entity class need to be identified
	 * @return Persistence entity's class
	 * @throws IllegalArgumentException
	 *             If entity class could not be identified
	 */
	@SuppressWarnings("unchecked")
	private Class<T> getParameterizedClass(final Class<?> targetClass) throws IllegalArgumentException {
		final Type type = targetClass.getGenericSuperclass();
		if (type instanceof ParameterizedType) {
			final ParameterizedType paramType = (ParameterizedType) type;
			return (Class<T>) paramType.getActualTypeArguments()[0];
		}
		final Class<?> superClass = targetClass.getSuperclass();
		if (superClass != targetClass) {
			return this.getParameterizedClass(superClass);
		}
		throw new IllegalArgumentException("Could not find entity class by reflection");
	}

}
