package com.unibet.worktest.bank;

/**
 * The exception thrown if transaction is not found
 * 
 * @author kanika
 *
 */
public class TransactionNotFoundException extends BusinessException {

	private static final long serialVersionUID = 1L;

	public TransactionNotFoundException(String message) {
		super(message);
	}

}
