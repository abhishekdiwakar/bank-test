package com.unibet.worktest.bank;

/**
 * The exception thrown if error occurs while creating a new account.
 * 
 * @author kanika
 *
 */
public class AccountDetailsMissingException extends BusinessException {

	private static final long serialVersionUID = 1L;

	public AccountDetailsMissingException(String message) {
		super(message);
	}
}
