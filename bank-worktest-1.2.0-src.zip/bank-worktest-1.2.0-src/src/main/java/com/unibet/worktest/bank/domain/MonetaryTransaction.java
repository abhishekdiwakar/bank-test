package com.unibet.worktest.bank.domain;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.hibernate.annotations.Immutable;

/**
 *
 * Immutable Hibernate entity to persist the Transaction details
 *
 * @see MonetaryTransactionLeg
 * 
 *
 */
@Entity
@NamedQueries({
		@NamedQuery(name = "transaction.findTransactionsByAccountRef", query = "select mt from MonetaryTransaction mt join mt.legs l join l.account acc where acc.accountRef = :accountRef")
})
@Immutable
public class MonetaryTransaction {

	@Id
	private String transactionRef;

	@Column(nullable = false)
	private String transactionType;

	@Column(nullable = false)
	private Date transactionDate;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "transactionRef")
	private List<MonetaryTransactionLeg> legs;

	@PreUpdate
	@PrePersist
	public void convertMoney() {
		this.transactionDate = new Date();
	}

	public MonetaryTransaction() {
	}

	public MonetaryTransaction(String transactionRef, String transactionType, List<MonetaryTransactionLeg> legs) {
		this.transactionRef = transactionRef;
		this.transactionType = transactionType;
		this.legs = legs;
	}

	public String getTransactionRef() {
		return transactionRef;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public List<MonetaryTransactionLeg> getLegs() {
		return legs;
	}

}
